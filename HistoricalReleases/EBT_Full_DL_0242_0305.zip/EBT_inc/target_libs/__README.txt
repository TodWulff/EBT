The currently recognized chip types are detailed in the following:

MK20DX128
MK20DX256
LPC54102
LPC54005
LPC11U37
LPC11U67
LPC11U68
SAMD21
LPC[string range $cpuType 1 3]
LPC$cpuType
